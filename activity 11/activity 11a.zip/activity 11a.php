<html>
<head><title>ACTIVITY 11A</title></head>
<body>
	<?php
	for($i=7;$i>=1;$i--)
	{	
		for($j=1;$j<=$i;$j++)
		{
			echo "$j";
		}
		echo"<br>";
	}
	for($k=2;$k<=7;$k++)
	{	
		for($l=1;$l<=$k;$l++)
		{
			echo "$l";
		}
		echo"<br>";
	} 
	?>
	
</body>
</html>
